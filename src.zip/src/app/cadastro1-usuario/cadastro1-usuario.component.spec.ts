import { ComponentFixture, TestBed } from '@angular/core/testing';

import { Cadastro1UsuarioComponent } from './cadastro1-usuario.component';

describe('Cadastro1UsuarioComponent', () => {
  let component: Cadastro1UsuarioComponent;
  let fixture: ComponentFixture<Cadastro1UsuarioComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [Cadastro1UsuarioComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(Cadastro1UsuarioComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
