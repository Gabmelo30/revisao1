import { Component } from '@angular/core';

@Component({
  selector: 'app-cadastro1-usuario',
  standalone: true,
  imports: [],
  templateUrl: './cadastro1-usuario.component.html',
  styleUrl: './cadastro1-usuario.component.css'
})
export class Cadastro1UsuarioComponent {
usuario: Usuario[] = [];

constructor(private UsuarioService: UsuarioService) {}

ngOnInit() {
  this.usuario = this.UsuarioService.obterUsuario();
}
}
