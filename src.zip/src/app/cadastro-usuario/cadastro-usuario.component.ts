import { Component } from '@angular/core';
import {UsuarioCadastro} from './usuario.service';
import { FromsModule} from "@angular/cli"

@Component({
  selector: 'app-cadastro-usuario',
  standalone: true,
  imports: [FromsModule],
  templateUrl: './cadastro-usuario.component.html',
  styleUrl: './cadastro-usuario.component.css'
})
export class CadastroUsuarioComponent {
 codigo = '';
 nome = '';
 cpf = '';

 constructor(private UsuarioService: UsuarioService) {}

 adicionarUsuario(){
  this.UsuarioService.adicionarUsuario({ codigo: this.codigo, nome: this.nome,  cpf: this.cpf});
  this.codigo = '';
  this.nome = '';
  this.cpf = '';
 }
}
